# 6400 Self-Assessment — Installable Offline App

PDC Services · 55 Pa. Code Chapter 6400

## What's in this folder
| File | Purpose |
|---|---|
| `index.html` | The full app (Self-Assessment, Checklist Licensing, 6400.141, 6400.163, 6400.22, Fire Drills, Quality & Reports, Summary) |
| `manifest.webmanifest` | Lets devices install it as an app |
| `sw.js` | Offline support |
| `icons/` | App icons |
| `.nojekyll` | Needed for GitHub Pages |

## Step 1 — Host the folder (one time)
The app must be served over **https** to install and work offline. Free option: **GitHub Pages**.

1. Create a free account at github.com.
2. Click **New repository** → name it `6400-app` → set to **Public** → **Create repository**.
3. Click **uploading an existing file** → drag in **everything in this folder** (including the `icons` folder) → **Commit changes**.
4. Go to **Settings → Pages** → Source: **Deploy from a branch** → Branch: **main**, folder **/(root)** → **Save**.
5. Wait 1–2 minutes. Your app link appears at the top of the Pages screen, e.g. `https://yourname.github.io/6400-app/`.

Other options: your agency website, SharePoint/Azure Static Web Apps, or Netlify (drag the folder onto app.netlify.com/drop). Any host works if it uses https.

## Step 2 — Install on each device
Open the app link once with internet, then:

- **iPad / iPhone (Safari):** Share button → **Add to Home Screen** → **Add**.
- **Android (Chrome):** menu ⋮ → **Install app**.
- **Windows / Mac (Edge or Chrome):** install icon in the address bar → **Install**.

After the first open, it works **without internet**. An orange bar shows when you are offline.

## Step 3 — Protect the data
- Data is saved **only on that device**. It is not shared between devices or staff.
- **Back up often:** Summary page or Home page → **Back up all data (.json)**. Save the file to a secure agency location (OneDrive/SharePoint), not personal email.
- **Move data** to a new device or into the online team version: **Restore from backup** and pick the .json file.
- Deleting the app or clearing Safari/browser website data **erases** the data on that device. Back up first.
- Use a **passcode** on every device. Enter individuals by **initials or record number** only.

## Updating the app
When you get a new `index.html`, upload it to the same repository (replace the old file) and change `VERSION` in `sw.js` (e.g. `6400-v2`). Devices pick up the update the next time they open the app online.

## Reports
Reports download as Word (.doc). On iPad, the share sheet opens: choose **Save to Files** or open in **Word**, then print or save as PDF.
